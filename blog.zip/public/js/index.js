/**
 * Created by admin on 2016/12/29.
 */
var NavList = React.createClass({
    handleClickEvent:function(e){
        var index = $(e.currentTarget).index();
        this.setState({activeNum:index});
    },
    getInitialState:() => {
        return {activeNum:0}
    },
    render:function(){
        var navArray = this.props.nvaArr;
        return (
            <ul className="nav nav-pills ver_re_mid fr">
                {
                    navArray.map((comment,index) => <li className={index == this.state.activeNum?'active':''} onClick={this.handleClickEvent}><a href="#">{comment}</a></li>)
                }
            </ul>
        )
    }
});
var Header = React.createClass({
    getNavList:function(){
        $.ajax({
            url:this.props.navUrl,
            dataType:'json',
            cache:false,
            success:(data) => {
                this.setState({data:data});
            },
            error:(xhr,status,err) => {
                console.error(this.props.navUrl,status,err.toString());
            }
        })
    },
    getInitialState:function(){
        return {data:['Home']};
    },
    componentDidMount:function(){
        this.getNavList();
    },
    render:function(){
        return (
            <header>
                <img src={this.props.titleImg} className="img-circle ver_re_mid fl"/>
                <h2 className="title fl">{this.props.tName}</h2>
                <NavList nvaArr={this.state.data} />
            </header>
        )
    }
});
ReactDOM.render(
    <Header titleImg="img/head.jpg" tName="Mr.Yang" navUrl="/api/getNav"/>,
    document.getElementById('app')
);