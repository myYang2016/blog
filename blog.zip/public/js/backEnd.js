/**
 * Created by admin on 2016/12/29.
 */
var ChangeNav = React.createClass({
    handleCommentSubmit:function(e){
        e.preventDefault();
        var newNav = {newNav:this.state.newNav.trim(),type:this.props.btnName};
        $.ajax({
            url:this.props.postUrl,
            dataType:'json',
            type:'POST',
            data:newNav,
            success:function(){
                console.log("提交成功");
                this.setState({newNav:newNav.newNav})
            }.bind(this),
            error:function (xhr, status, err) {
                console.error(this.props.postUrl, status, err.toString());
            }.bind(this)
        })
    },
    handleNavChange:function(e){
        this.setState({newNav:e.target.value});
    },
    getInitialState:function(){
        return {newNav:''}
    },
    render:function(){
        var placeTxt = '';
        switch (this.props.btnName){
            case 'addNav':
                placeTxt = 'input new navName';
                break;
            case 'deleteNav':
                placeTxt = 'input old navName';
                break;
        }
        return (
            <form onSubmit={this.handleCommentSubmit}>
                <input type="text" name="newNav" placeholder={placeTxt} value={this.state.newNav} onChange={this.handleNavChange}/>
                <input type="submit" value={this.props.btnName}/>
            </form>
        )
    }
});
ReactDOM.render(
    <div>
        <ChangeNav postUrl="/api/postNav" btnName="addNav" />
        <ChangeNav postUrl="/api/postNav" btnName="deleteNav" />
    </div>,
    document.getElementById('backEnd')
);