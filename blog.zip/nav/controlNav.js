/**
 * Created by admin on 2016/12/29.
 */
var express = require('express');
var router = express.Router();
var fs = require('fs');

var COMMENT_URL = __dirname.match(/.*(?=\\[A-Za-z0-9]+$)/)[0];
router.use(function timeLog(req,res,next){
    console.log('Time:',Date.now());
    next();
});
//获取数据
router.get('/api/getNav',function(req,res){
    fs.readFile(COMMENT_URL + '/data/navList.json',function(err,data){
        if(err){
            console.error(err);
            process.exit(1);
        }
        res.json(JSON.parse(data));
    })
});
//上传数据
router.post('/api/postNav',function(req,res){
    fs.readFile(COMMENT_URL + '/data/navList.json',function(err,data){
        if(err){
            console.error(err);
            process.exit(1);
        }
        var comments = JSON.parse(data);
        var getData = req.body.newNav;
        var getType = req.body.type;
        switch (getType){
            case 'addNav':
                comments.push(getData);
                break;
            case 'deleteNav':
                console.log(comments.indexOf(getData));
                if(comments.indexOf(getData) >= 0){
                    comments.splice(comments.indexOf(getData),1);
                }
                break;
        }
        fs.writeFile(COMMENT_URL + '/data/navList.json',JSON.stringify(comments),function(err){
            if(err){
                console.error(err);
                process.exit(1);
            }
            res.json(comments);
        })
    })
});

module.exports = router;